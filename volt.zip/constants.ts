
import { Machine } from './types';

export const MACHINES: Machine[] = [
  {
    id: 'm1',
    name: 'Tower A - Lobby',
    location: 'Cyberpark Tower A, Ground Floor',
    status: 'Online',
    stockLevel: { whey: 85, vegan: 45 },
    queueLength: 0,
    distance: '2 min walk',
    coordinates: { lat: 28.4595, lng: 77.0266 }
  },
  {
    id: 'm2',
    name: 'Tower B - Gym Floor',
    location: 'Anytime Fitness, 3rd Floor',
    status: 'Online',
    stockLevel: { whey: 20, vegan: 90 },
    queueLength: 3,
    distance: '5 min walk',
    coordinates: { lat: 28.4598, lng: 77.0269 }
  },
  {
    id: 'm3',
    name: 'Tower C - Food Court',
    location: 'Cyberpark Food Court, 1st Floor',
    status: 'Offline',
    stockLevel: { whey: 60, vegan: 15 },
    queueLength: 0,
    distance: '8 min walk',
    coordinates: { lat: 28.4600, lng: 77.0272 }
  }
];

export const INGREDIENTS = {
  bases: [
    { id: 'whey', name: 'Whey Protein', price: 100, macros: { protein: 24, calories: 120, carbs: 3, fats: 2 } },
    { id: 'isolate', name: 'Whey Isolate', price: 150, macros: { protein: 27, calories: 110, carbs: 1, fats: 0 } },
    { id: 'vegan', name: 'Vegan Pea Protein', price: 120, macros: { protein: 22, calories: 130, carbs: 5, fats: 3 } },
  ],
  flavors: [
    { id: 'chocolate', name: 'Chocolate' },
    { id: 'vanilla', name: 'Vanilla' },
    { id: 'strawberry', name: 'Strawberry' },
    { id: 'coffee', name: 'Coffee' },
    { id: 'banana', name: 'Banana' },
  ],
  sizes: [
    { id: 'Small', name: 'Small (250ml)', multiplier: 1.0 },
    { id: 'Medium', name: 'Medium (350ml)', multiplier: 1.2 },
    { id: 'Large', name: 'Large (500ml)', multiplier: 1.5 },
  ],
  addOns: [
    { id: 'creatine', name: 'Creatine Monohydrate', price: 20, macros: { protein: 0, calories: 0, carbs: 0, fats: 0 } },
    { id: 'bcaa', name: 'BCAAs', price: 25, macros: { protein: 5, calories: 20, carbs: 0, fats: 0 } },
    { id: 'pb', name: 'Peanut Butter', price: 30, macros: { protein: 4, calories: 90, carbs: 3, fats: 8 } },
    { id: 'scoop', name: 'Extra Scoop', price: 80, macros: { protein: 20, calories: 100, carbs: 2, fats: 1 } },
  ]
};

export const PRESETS = [
  {
    id: 'preset1',
    name: 'Classic Gains',
    description: 'Standard Chocolate Whey for post-workout.',
    base: 'whey',
    flavor: 'chocolate',
    size: 'Medium',
    addOns: [],
    sweetness: 50,
    ice: 'Normal',
    price: 120,
    macros: { protein: 24, carbs: 5, fats: 2, calories: 140 }
  },
  {
    id: 'preset2',
    name: 'Vegan Power',
    description: 'Plant-based fuel with strawberry flavor.',
    base: 'vegan',
    flavor: 'strawberry',
    size: 'Large',
    addOns: ['bcaa'],
    sweetness: 25,
    ice: 'Extra',
    price: 205,
    macros: { protein: 22, carbs: 8, fats: 3, calories: 160 }
  }
];
