
import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { INGREDIENTS, PRESETS } from '../constants';
import { ShakeRecipe, MacroData } from '../types';
import { ChevronLeft, Check, Activity, Flame } from 'lucide-react';

const ShakeBuilder: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const machineId = searchParams.get('machineId');
  const presetId = searchParams.get('preset');

  const [recipe, setRecipe] = useState<ShakeRecipe>({
    base: 'whey',
    flavor: 'chocolate',
    size: 'Medium',
    addOns: [],
    sweetness: 50,
    ice: 'Normal',
    price: 0,
    macros: { protein: 0, carbs: 0, fats: 0, calories: 0 }
  });

  // Load preset if exists
  useEffect(() => {
    if (presetId) {
        const preset = PRESETS.find(p => p.id === presetId);
        if (preset) {
            setRecipe({
                base: preset.base,
                flavor: preset.flavor,
                size: preset.size as any,
                addOns: preset.addOns,
                sweetness: preset.sweetness,
                ice: preset.ice as any,
                price: preset.price,
                name: preset.name,
                macros: preset.macros
            });
        }
    } else {
        recalculate();
    }
  }, [presetId]);

  useEffect(() => {
    recalculate();
  }, [recipe.base, recipe.size, recipe.addOns.length]);

  const recalculate = () => {
      const baseObj = INGREDIENTS.bases.find(b => b.id === recipe.base);
      const sizeObj = INGREDIENTS.sizes.find(s => s.id === recipe.size);
      
      const basePrice = baseObj?.price || 0;
      const sizeMult = sizeObj?.multiplier || 1;
      
      // Calculate Price
      let addonsPrice = 0;
      let totalMacros: MacroData = { protein: 0, carbs: 0, fats: 0, calories: 0 };

      // Base Macros * Size Multiplier
      if (baseObj?.macros) {
          totalMacros.protein += baseObj.macros.protein * sizeMult;
          totalMacros.carbs += baseObj.macros.carbs * sizeMult;
          totalMacros.fats += baseObj.macros.fats * sizeMult;
          totalMacros.calories += baseObj.macros.calories * sizeMult;
      }

      // Addons
      recipe.addOns.forEach(id => {
          const addon = INGREDIENTS.addOns.find(a => a.id === id);
          if (addon) {
              addonsPrice += addon.price;
              if (addon.macros) {
                totalMacros.protein += addon.macros.protein;
                totalMacros.carbs += addon.macros.carbs;
                totalMacros.fats += addon.macros.fats;
                totalMacros.calories += addon.macros.calories;
              }
          }
      });
      
      const totalPrice = Math.round((basePrice * sizeMult) + addonsPrice);
      
      setRecipe(prev => ({ 
          ...prev, 
          price: totalPrice,
          macros: {
              protein: Math.round(totalMacros.protein),
              carbs: Math.round(totalMacros.carbs),
              fats: Math.round(totalMacros.fats),
              calories: Math.round(totalMacros.calories),
          }
      }));
  };

  const toggleAddOn = (id: string) => {
      setRecipe(prev => {
          const newAddOns = prev.addOns.includes(id) 
            ? prev.addOns.filter(a => a !== id) 
            : [...prev.addOns, id];
          return { ...prev, addOns: newAddOns };
      });
  };

  const handleContinue = () => {
      navigate('/app/order-summary', { state: { recipe, machineId } });
  };

  return (
    <div className="pb-32">
      <div className="flex items-center gap-2 mb-6 text-white">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-white/10 rounded-full transition-colors">
              <ChevronLeft size={24} />
          </button>
          <h1 className="text-xl font-bold font-display">Configure Fuel</h1>
      </div>

      <div className="space-y-8">
          
          {/* MACROS CARD (Sticky on mobile or top) */}
          <div className="bg-card border border-primary/20 rounded-2xl p-5 shadow-lg relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-2xl -z-10"></div>
              <div className="flex justify-between items-center mb-4">
                  <h3 className="font-bold text-white flex items-center gap-2 font-display">
                      <Activity size={18} className="text-primary" /> Macros
                  </h3>
                  <div className="text-xs font-bold bg-gray-800 px-2 py-1 rounded text-gray-400">PER SHAKE</div>
              </div>
              <div className="grid grid-cols-4 gap-2 text-center">
                  <div className="bg-dark/50 p-2 rounded-lg border border-darkBorder">
                      <div className="text-lg font-bold text-white">{recipe.macros?.protein}g</div>
                      <div className="text-[10px] text-gray-500 uppercase font-bold">Protein</div>
                  </div>
                  <div className="bg-dark/50 p-2 rounded-lg border border-darkBorder">
                      <div className="text-lg font-bold text-white">{recipe.macros?.calories}</div>
                      <div className="text-[10px] text-gray-500 uppercase font-bold">Cals</div>
                  </div>
                  <div className="bg-dark/50 p-2 rounded-lg border border-darkBorder">
                      <div className="text-lg font-bold text-white">{recipe.macros?.carbs}g</div>
                      <div className="text-[10px] text-gray-500 uppercase font-bold">Carbs</div>
                  </div>
                  <div className="bg-dark/50 p-2 rounded-lg border border-darkBorder">
                      <div className="text-lg font-bold text-white">{recipe.macros?.fats}g</div>
                      <div className="text-[10px] text-gray-500 uppercase font-bold">Fats</div>
                  </div>
              </div>
          </div>

          {/* Base Protein */}
          <section>
              <h3 className="font-bold text-gray-400 mb-3 text-sm uppercase tracking-wider">Base Protein</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {INGREDIENTS.bases.map(base => (
                      <button 
                        key={base.id}
                        onClick={() => setRecipe({...recipe, base: base.id})}
                        className={`p-4 rounded-xl border-2 text-left transition-all ${
                            recipe.base === base.id 
                            ? 'border-primary bg-primary/10' 
                            : 'border-darkBorder bg-card hover:border-gray-600'
                        }`}
                      >
                          <div className={`font-bold ${recipe.base === base.id ? 'text-primary' : 'text-white'}`}>{base.name}</div>
                          <div className="text-xs text-gray-500">{base.macros?.protein}g Protein</div>
                      </button>
                  ))}
              </div>
          </section>

          {/* Size */}
          <section>
              <h3 className="font-bold text-gray-400 mb-3 text-sm uppercase tracking-wider">Size Multiplier</h3>
              <div className="grid grid-cols-3 gap-3">
                  {INGREDIENTS.sizes.map(size => (
                      <button 
                        key={size.id}
                        onClick={() => setRecipe({...recipe, size: size.id as any})}
                        className={`p-3 rounded-xl border text-center transition-all ${
                            recipe.size === size.id 
                            ? 'bg-primary text-dark border-primary font-bold' 
                            : 'bg-card text-gray-400 border-darkBorder hover:border-gray-600'
                        }`}
                      >
                          <div className="text-sm">{size.name.split(' ')[0]}</div>
                          <div className="text-[10px] opacity-70">x{size.multiplier}</div>
                      </button>
                  ))}
              </div>
          </section>

          {/* Flavor */}
          <section>
              <h3 className="font-bold text-gray-400 mb-3 text-sm uppercase tracking-wider">Flavor</h3>
              <div className="flex flex-wrap gap-2">
                  {INGREDIENTS.flavors.map(flavor => (
                      <button 
                        key={flavor.id}
                        onClick={() => setRecipe({...recipe, flavor: flavor.id})}
                        className={`px-4 py-2 rounded-full border text-sm font-medium transition-all ${
                            recipe.flavor === flavor.id 
                            ? 'bg-white text-dark border-white' 
                            : 'bg-transparent text-gray-400 border-gray-700 hover:border-gray-500 hover:text-white'
                        }`}
                      >
                          {flavor.name}
                      </button>
                  ))}
              </div>
          </section>

          {/* Add-ons */}
          <section>
              <h3 className="font-bold text-gray-400 mb-3 text-sm uppercase tracking-wider">Performance Boosters</h3>
              <div className="grid grid-cols-2 gap-3">
                  {INGREDIENTS.addOns.map(addon => {
                      const isSelected = recipe.addOns.includes(addon.id);
                      return (
                        <button 
                            key={addon.id}
                            onClick={() => toggleAddOn(addon.id)}
                            className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                                isSelected 
                                ? 'border-primary bg-primary/10' 
                                : 'border-darkBorder bg-card hover:border-gray-600'
                            }`}
                        >
                            <div className="text-left">
                                <div className={`font-medium ${isSelected ? 'text-primary' : 'text-gray-200'}`}>{addon.name}</div>
                                <div className="text-xs text-gray-500">+{addon.macros?.calories} cal</div>
                            </div>
                            {isSelected && <div className="bg-primary text-dark rounded-full p-0.5"><Check size={12} strokeWidth={3} /></div>}
                        </button>
                      );
                  })}
              </div>
          </section>
      </div>

      {/* Footer */}
      <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-darkBorder p-4 shadow-2xl z-30 md:relative md:border-0 md:shadow-none md:bg-transparent md:p-0 md:mt-8">
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-4">
            <div>
                <span className="block text-xs text-gray-500 uppercase tracking-wide">Total</span>
                <span className="block text-3xl font-bold text-white font-display">₹{recipe.price}</span>
            </div>
            <button 
                onClick={handleContinue}
                className="flex-1 bg-primary hover:bg-cyan-400 text-dark font-bold py-4 rounded-xl transition-all shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2"
            >
                Review & Pay <Flame size={18} fill="currentColor" />
            </button>
        </div>
      </div>
    </div>
  );
};

export default ShakeBuilder;
