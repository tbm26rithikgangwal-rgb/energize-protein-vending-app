import React from 'react';

const Help: React.FC = () => {
  return (
    <div className="space-y-6">
        <h1 className="text-2xl font-bold text-white font-display">Support</h1>

        <div className="bg-card rounded-2xl border border-darkBorder overflow-hidden">
            <h2 className="font-bold p-4 bg-gray-800/50 border-b border-darkBorder text-gray-200">System FAQs</h2>
            {[
                { q: "Machine error / Dispense failure", a: "Use the 'Report' function in order history. Hardware errors trigger auto-refunds within 5 mins." },
                { q: "Wallet refund timeline", a: "Refunds are processed instantly to your app wallet." },
                { q: "Isolate vs Whey", a: "Isolate is filtered for faster absorption and lower carbs, ideal for immediate post-workout recovery." }
            ].map((faq, i) => (
                <div key={i} className="p-4 border-b border-darkBorder last:border-0">
                    <h3 className="font-bold text-sm text-primary mb-1">{faq.q}</h3>
                    <p className="text-sm text-gray-400">{faq.a}</p>
                </div>
            ))}
        </div>

        <div className="bg-card rounded-2xl border border-darkBorder p-6">
            <h2 className="font-bold text-lg mb-4 text-white">Open Ticket</h2>
            <textarea 
                className="w-full h-32 bg-dark border border-gray-700 rounded-lg p-3 text-sm text-white focus:ring-2 focus:ring-primary outline-none resize-none placeholder-gray-600"
                placeholder="Describe hardware issue or transaction error..."
            ></textarea>
            <button className="mt-4 bg-white text-dark px-6 py-2 rounded-lg font-bold text-sm hover:bg-gray-200 transition-colors">
                Submit Ticket
            </button>
        </div>

        <p className="text-center text-sm text-gray-500">
            For instant diagnostics, ask <span className="text-primary font-bold">ProteinBot</span> below.
        </p>
    </div>
  );
};

export default Help;