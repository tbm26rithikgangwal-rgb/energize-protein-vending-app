import React, { useState } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { ShakeRecipe } from '../types';
import { ChevronLeft, AlertTriangle } from 'lucide-react';

const OrderSummary: React.FC = () => {
  const { state } = useLocation();
  const navigate = useNavigate();
  const { user, createOrder } = useApp();
  const [loading, setLoading] = useState(false);

  // Parse state
  const recipe = state?.recipe as ShakeRecipe;
  const machineId = state?.machineId as string;

  if (!recipe || !machineId) {
      return <div className="p-8 text-center text-white">Invalid Order State. <Link to="/app/machines" className="text-primary underline">Go back</Link></div>;
  }

  const canPay = user && user.walletBalance >= recipe.price;
  const deficit = user ? recipe.price - user.walletBalance : 0;

  const handlePay = async () => {
      if (!canPay) return;
      setLoading(true);
      try {
          const orderId = await createOrder(machineId, recipe, recipe.price);
          navigate(`/app/orders/${orderId}`);
      } catch (e) {
          alert('Payment failed: ' + e);
          setLoading(false);
      }
  };

  return (
    <div className="max-w-md mx-auto">
      <div className="flex items-center gap-2 mb-6 text-white">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-white/10 rounded-full transition-colors">
              <ChevronLeft size={24} />
          </button>
          <h1 className="text-xl font-bold font-display">Confirm Transaction</h1>
      </div>

      <div className="bg-card rounded-2xl shadow-sm border border-darkBorder overflow-hidden mb-6">
          <div className="p-6 border-b border-darkBorder">
              <h2 className="font-bold text-xl mb-1 text-white">{recipe.name || 'Custom Build'}</h2>
              <div className="text-gray-400 text-sm">
                  {recipe.size} • {recipe.flavor} {recipe.base}
              </div>
          </div>
          <div className="p-6 bg-dark/50 space-y-3 text-sm">
              <div className="flex justify-between">
                  <span className="text-gray-500">Base Price</span>
                  <span className="font-medium text-gray-300">Included</span>
              </div>
              {recipe.addOns.length > 0 && (
                  <div className="flex justify-between">
                      <span className="text-gray-500">Add-ons ({recipe.addOns.length})</span>
                      <span className="font-medium text-gray-300">Included</span>
                  </div>
              )}
              <div className="flex justify-between border-t border-gray-700 pt-3 mt-2">
                  <span className="font-bold text-white text-lg">Total</span>
                  <span className="font-bold text-primary text-lg">₹{recipe.price}</span>
              </div>
          </div>
      </div>

      {/* Wallet Info */}
      <div className={`p-4 rounded-xl border mb-6 transition-colors ${canPay ? 'bg-green-500/10 border-green-500/20' : 'bg-red-500/10 border-red-500/20'}`}>
          <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-300">Wallet Balance</span>
              <span className={`font-bold ${canPay ? 'text-green-400' : 'text-red-400'}`}>₹{user?.walletBalance}</span>
          </div>
          {!canPay && (
              <div className="flex items-start gap-2 text-red-400 text-xs mt-2">
                  <AlertTriangle size={14} className="mt-0.5" />
                  <span>Insufficient funds. Deficit: ₹{deficit}</span>
              </div>
          )}
      </div>

      {/* Actions */}
      <div className="space-y-3">
          {canPay ? (
              <button 
                onClick={handlePay}
                disabled={loading}
                className="w-full bg-primary hover:bg-cyan-400 text-dark font-bold py-4 rounded-xl shadow-lg shadow-cyan-500/20 disabled:opacity-70 flex justify-center items-center gap-2 transition-all"
              >
                  {loading ? (
                      <>Processing Transaction...</>
                  ) : (
                      <>Pay ₹{recipe.price} & Dispense</>
                  )}
              </button>
          ) : (
              <button 
                onClick={() => navigate('/app/wallet')}
                className="w-full bg-white text-dark hover:bg-gray-200 font-bold py-4 rounded-xl transition-colors"
              >
                  Add Money to Wallet
              </button>
          )}
      </div>
    </div>
  );
};

export default OrderSummary;