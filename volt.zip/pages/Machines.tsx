import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MachineCard from '../components/MachineCard';
import { MACHINES } from '../constants';
import { suggestMachine } from '../services/geminiService';
import { Sparkles, Loader2 } from 'lucide-react';

const Machines: React.FC = () => {
  const navigate = useNavigate();
  const [filter, setFilter] = useState<'nearest' | 'stock'>('nearest');
  const [aiQuery, setAiQuery] = useState('');
  const [isAskingAi, setIsAskingAi] = useState(false);

  const sortedMachines = [...MACHINES].sort((a, b) => {
    if (filter === 'nearest') {
        return a.id.localeCompare(b.id);
    }
    return 0;
  });

  const handleAskAi = async () => {
    if (!aiQuery) return;
    setIsAskingAi(true);
    const suggestedId = await suggestMachine(aiQuery, MACHINES);
    setIsAskingAi(false);
    navigate(`/app/machines/${suggestedId}`);
  };

  return (
    <div className="space-y-6">
        <div className="flex flex-col gap-4">
            <h1 className="text-2xl font-bold text-white font-display">Select Unit</h1>
            
            {/* AI Helper */}
            <div className="bg-card border border-primary/20 p-4 rounded-xl shadow-lg relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-2xl -z-10"></div>
                <div className="flex items-center gap-2 mb-2 text-primary font-bold text-sm uppercase tracking-wide">
                    <Sparkles size={16} />
                    <span>Smart Locator</span>
                </div>
                <div className="flex gap-2">
                    <input 
                        type="text" 
                        value={aiQuery}
                        onChange={(e) => setAiQuery(e.target.value)}
                        placeholder="e.g. 'I'm near the Food Court'"
                        className="flex-1 text-sm bg-dark border border-gray-700 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all placeholder-gray-500"
                    />
                    <button 
                        onClick={handleAskAi}
                        disabled={!aiQuery || isAskingAi}
                        className="bg-primary hover:bg-cyan-400 text-dark px-4 py-2 rounded-lg text-sm font-bold disabled:opacity-50 transition-colors min-w-[80px] flex justify-center"
                    >
                        {isAskingAi ? <Loader2 size={16} className="animate-spin" /> : 'Find'}
                    </button>
                </div>
            </div>

            {/* Filters */}
            <div className="flex items-center justify-between">
                <div className="flex gap-2">
                    <button 
                        onClick={() => setFilter('nearest')}
                        className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors border ${filter === 'nearest' ? 'bg-gray-700 text-white border-gray-600' : 'bg-transparent text-gray-500 border-gray-800 hover:border-gray-600'}`}
                    >
                        Nearest
                    </button>
                    <button 
                        onClick={() => setFilter('stock')}
                        className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors border ${filter === 'stock' ? 'bg-gray-700 text-white border-gray-600' : 'bg-transparent text-gray-500 border-gray-800 hover:border-gray-600'}`}
                    >
                        Best Stock
                    </button>
                </div>
                <span className="text-xs text-gray-500">{MACHINES.length} units active</span>
            </div>
        </div>

        <div className="grid gap-4">
            {sortedMachines.map(machine => (
                <MachineCard 
                    key={machine.id} 
                    machine={machine} 
                    onSelect={(id) => navigate(`/app/machines/${id}`)} 
                />
            ))}
        </div>
    </div>
  );
};

export default Machines;