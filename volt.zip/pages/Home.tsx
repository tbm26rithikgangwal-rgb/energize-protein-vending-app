
import React, { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';
import { analyzeWorkoutForShake, getMotivationQuote } from '../services/geminiService';
import { ShakeRecipe } from '../types';
import { useNavigate, Link } from 'react-router-dom';
import { Sparkles, MapPin, Plus, Flame, Dumbbell, Zap, Activity, Clock, Sun, Moon } from 'lucide-react';

const Home: React.FC = () => {
  const { user, orders } = useApp();
  const navigate = useNavigate();
  const [workoutInput, setWorkoutInput] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [generatedShake, setGeneratedShake] = useState<(Partial<ShakeRecipe> & { reasoning: string }) | null>(null);
  const [motivation, setMotivation] = useState('Loading hype...');
  const [timeContext, setTimeContext] = useState<'morning' | 'day' | 'evening'>('day');

  useEffect(() => {
      if (user) {
          getMotivationQuote(user).then(setMotivation);
          
          const hour = new Date().getHours();
          if(hour < 11) setTimeContext('morning');
          else if(hour > 18) setTimeContext('evening');
          else setTimeContext('day');
      }
  }, [user]);

  const handleWorkoutAnalysis = async () => {
      if(!workoutInput.trim()) return;
      setAnalyzing(true);
      const result = await analyzeWorkoutForShake(workoutInput);
      setGeneratedShake(result);
      setAnalyzing(false);
  };

  if(!user) return null;

  // Energy Meter SVG Config
  const radius = 30;
  const stroke = 4;
  const normalizedRadius = radius - stroke * 2;
  const circumference = normalizedRadius * 2 * Math.PI;
  const strokeDashoffset = circumference - (user.energyScore / 100) * circumference;

  return (
    <div className="space-y-8 pb-20">
      
      {/* 1. HERO STATUS: Energy Meter & Streak */}
      <div className="grid grid-cols-3 gap-3">
          {/* Energy Meter */}
          <div className="col-span-1 bg-gradient-to-b from-gray-900 to-black p-3 rounded-2xl border border-darkBorder flex flex-col items-center justify-center relative overflow-hidden">
               <div className="relative w-16 h-16 flex items-center justify-center">
                    <svg height={radius * 2} width={radius * 2} className="transform -rotate-90">
                        <circle stroke="#333" strokeWidth={stroke} fill="transparent" r={normalizedRadius} cx={radius} cy={radius} />
                        <circle 
                            stroke={user.energyScore < 30 ? '#ef4444' : '#00FF88'} 
                            strokeDasharray={circumference + ' ' + circumference} 
                            style={{ strokeDashoffset, transition: 'stroke-dashoffset 1s ease-in-out' }} 
                            strokeWidth={stroke} 
                            strokeLinecap="round"
                            fill="transparent" 
                            r={normalizedRadius} 
                            cx={radius} 
                            cy={radius} 
                        />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center flex-col">
                        <Zap size={16} className={user.energyScore < 30 ? 'text-red-500' : 'text-accent'} fill="currentColor" />
                    </div>
               </div>
               <span className="text-[10px] uppercase font-bold text-gray-500 mt-2">Energy</span>
               <span className="text-lg font-bold text-white font-display">{user.energyScore}%</span>
          </div>

          {/* Streak & Wallet */}
          <div className="col-span-2 grid grid-rows-2 gap-3">
              <div className="bg-card px-4 py-2 rounded-xl border border-darkBorder flex justify-between items-center group relative overflow-hidden">
                   <div className="absolute inset-0 bg-energy/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                   <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-energy/10 flex items-center justify-center text-energy">
                            <Flame size={16} fill="currentColor" className="animate-pulse" />
                        </div>
                        <div>
                            <div className="text-xs text-gray-500 uppercase font-bold">Streak</div>
                            <div className="text-xl font-bold text-white leading-none">{user.streak} Days</div>
                        </div>
                   </div>
              </div>

              <div className="bg-card px-4 py-2 rounded-xl border border-darkBorder flex justify-between items-center cursor-pointer hover:bg-gray-800 transition-colors" onClick={() => navigate('/app/wallet')}>
                   <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                            <Plus size={16} />
                        </div>
                        <div>
                            <div className="text-xs text-gray-500 uppercase font-bold">Credits</div>
                            <div className="text-xl font-bold text-white leading-none">₹{user.walletBalance}</div>
                        </div>
                   </div>
              </div>
          </div>
      </div>

      {/* 2. DYNAMIC CONTEXT BANNER */}
      <div className={`p-4 rounded-xl border-l-4 flex items-center gap-3 shadow-lg ${
          timeContext === 'morning' ? 'bg-orange-500/10 border-orange-500' : 
          timeContext === 'evening' ? 'bg-purple-500/10 border-purple-500' : 'bg-primary/10 border-primary'
      }`}>
          {timeContext === 'morning' && <Sun size={20} className="text-orange-500" />}
          {timeContext === 'evening' && <Moon size={20} className="text-purple-500" />}
          {timeContext === 'day' && <Activity size={20} className="text-primary" />}
          <div>
              <p className="text-sm font-bold text-gray-200">{motivation}</p>
          </div>
      </div>

      {/* 3. NEURO-FUEL ARCHITECT */}
      <div className="bg-gradient-to-br from-secondary/20 to-dark p-1 rounded-2xl shadow-2xl shadow-secondary/10">
        <div className="bg-card rounded-xl p-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-secondary/20 rounded-full blur-[80px] -z-10 pointer-events-none"></div>
            
            <div className="flex items-center gap-2 mb-4">
                <Sparkles size={20} className="text-secondary animate-pulse" />
                <h2 className="text-xl font-bold text-white font-display">Neuro-Fuel Architect</h2>
            </div>
            
            {!generatedShake ? (
                <div className="space-y-3">
                    <div className="relative group">
                        <input 
                            type="text" 
                            value={workoutInput}
                            onChange={(e) => setWorkoutInput(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleWorkoutAnalysis()}
                            placeholder="e.g. 'Leg day: 5x5 squats'"
                            className="w-full bg-dark/80 border border-gray-700 rounded-xl px-4 py-4 pl-12 text-white placeholder-gray-500 focus:ring-2 focus:ring-secondary outline-none transition-all"
                        />
                        <Dumbbell className="absolute left-4 top-4 text-gray-500 group-hover:text-secondary transition-colors" size={20} />
                    </div>
                    <button 
                        onClick={handleWorkoutAnalysis}
                        disabled={analyzing || !workoutInput}
                        className="w-full bg-secondary hover:bg-purple-600 text-white font-bold py-4 rounded-xl transition-all shadow-[0_0_20px_rgba(122,51,255,0.3)] disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                        {analyzing ? <Activity className="animate-spin" size={20} /> : <Zap size={20} />}
                        {analyzing ? 'Analyzing Biometrics...' : 'Generate Formula'}
                    </button>
                </div>
            ) : (
                <div className="bg-dark border border-secondary/30 rounded-xl p-5 animate-slide-up">
                    <div className="flex justify-between items-start mb-4">
                        <h3 className="font-bold text-xl text-white font-display">{generatedShake.name}</h3>
                        <button 
                            onClick={() => navigate(`/app/shake-builder?machineId=m1&preset=custom`)}
                            className="bg-white text-dark px-4 py-2 rounded-lg font-bold text-xs uppercase tracking-wide"
                        >
                            Build Now
                        </button>
                    </div>
                    <div className="bg-secondary/10 border-l-2 border-secondary p-3 rounded-r-lg">
                        <p className="text-xs text-gray-300 italic">"{generatedShake.reasoning}"</p>
                    </div>
                    <button onClick={() => setGeneratedShake(null)} className="text-xs text-gray-600 mt-4 underline w-full text-center">Reset</button>
                </div>
            )}
        </div>
      </div>

      {/* 4. RECENT ACTIVITY */}
      <div>
        <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold text-lg text-white font-display">Recent Fuel</h2>
            <Link to="/app/orders" className="text-xs text-primary font-bold uppercase tracking-wide">View History</Link>
        </div>
        {orders.slice(0, 3).map(order => (
            <Link key={order.id} to={`/app/orders/${order.id}`} className="block bg-card p-4 mb-3 rounded-xl border border-darkBorder hover:border-primary/50 transition-all group">
                <div className="flex justify-between items-center">
                    <div className="flex gap-4 items-center">
                        <div className="w-10 h-10 bg-dark rounded-xl flex items-center justify-center text-gray-500 border border-darkBorder group-hover:text-primary transition-all">
                            <Clock size={18} />
                        </div>
                        <div>
                            <h3 className="font-bold text-white text-sm group-hover:text-primary">{order.shake.name || 'Custom Mix'}</h3>
                            <p className="text-xs text-gray-500">{new Date(order.date).toLocaleDateString()}</p>
                        </div>
                    </div>
                    <span className="font-bold text-white text-sm">₹{order.totalAmount}</span>
                </div>
            </Link>
        ))}
      </div>

      {/* 5. QUICK ACTIONS */}
      <div className="grid grid-cols-2 gap-4">
        <Link to="/app/machines" className="bg-primary/10 border border-primary/20 p-5 rounded-xl text-center group">
            <MapPin size={24} className="text-primary mx-auto mb-2 group-hover:scale-110 transition-transform" />
            <span className="font-bold text-white text-sm">Find Machine</span>
        </Link>
        <Link to="/app/shake-builder" className="bg-accent/10 border border-accent/20 p-5 rounded-xl text-center group">
            <Plus size={24} className="text-accent mx-auto mb-2 group-hover:scale-110 transition-transform" />
            <span className="font-bold text-white text-sm">Quick Build</span>
        </Link>
      </div>
    </div>
  );
};

export default Home;
