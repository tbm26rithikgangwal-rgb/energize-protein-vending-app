import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Zap, Mail, Smartphone, Loader2, CheckCircle, ArrowRight, ShieldCheck } from 'lucide-react';

const Signup: React.FC = () => {
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', password: '' });
  const [step, setStep] = useState<'form' | 'verifying' | 'otp' | 'success'>('form');
  const [otp, setOtp] = useState(['', '', '', '']);
  const { signup } = useApp();
  const navigate = useNavigate();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.email && formData.phone) {
        setStep('verifying');
        // Simulate sending OTP
        setTimeout(() => setStep('otp'), 1500);
    }
  };

  const handleVerifyOtp = async () => {
      setStep('verifying');
      // Simulate verification and database creation
      await signup(formData);
      setStep('success');
      setTimeout(() => navigate('/app/home'), 1500);
  };

  const handleOtpChange = (index: number, value: string) => {
      if (value.length > 1) return;
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);
      // Auto focus next
      if (value && index < 3) document.getElementById(`otp-${index + 1}`)?.focus();
  };

  return (
    <div className="min-h-screen bg-dark flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Energy */}
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-dark to-dark -z-10"></div>
      
      <div className="bg-card w-full max-w-md p-8 rounded-2xl shadow-[0_0_50px_-12px_rgba(0,102,255,0.2)] border border-darkBorder relative z-10 glass">
        
        {/* Header */}
        <div className="text-center mb-8">
            <div className="w-14 h-14 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-primary/30 animate-float">
                <Zap size={28} className="text-white" fill="currentColor" />
            </div>
            <h1 className="text-3xl font-bold text-white font-display tracking-wide">
                JOIN THE <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">ELITE</span>
            </h1>
            <p className="text-gray-500 mt-2 text-sm">Fuel your body. Dominate your day.</p>
        </div>

        {/* Step 1: Form */}
        {step === 'form' && (
            <form onSubmit={handleRegister} className="space-y-4 animate-slide-up">
                <div>
                    <input 
                        name="name" type="text" placeholder="Full Name" required 
                        value={formData.name} onChange={handleInputChange}
                        className="w-full px-5 py-4 bg-dark/50 border border-darkBorder rounded-xl text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all placeholder-gray-600"
                    />
                </div>
                <div className="relative">
                    <Mail size={18} className="absolute left-4 top-4.5 text-gray-500" />
                    <input 
                        name="email" type="email" placeholder="Email Address" required 
                        value={formData.email} onChange={handleInputChange}
                        className="w-full pl-12 pr-5 py-4 bg-dark/50 border border-darkBorder rounded-xl text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all placeholder-gray-600"
                    />
                </div>
                <div className="relative">
                    <Smartphone size={18} className="absolute left-4 top-4.5 text-gray-500" />
                    <input 
                        name="phone" type="tel" placeholder="Mobile Number" required 
                        value={formData.phone} onChange={handleInputChange}
                        className="w-full pl-12 pr-5 py-4 bg-dark/50 border border-darkBorder rounded-xl text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all placeholder-gray-600"
                    />
                </div>
                <div>
                    <input 
                        name="password" type="password" placeholder="Password" required 
                        value={formData.password} onChange={handleInputChange}
                        className="w-full px-5 py-4 bg-dark/50 border border-darkBorder rounded-xl text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all placeholder-gray-600"
                    />
                </div>
                
                <button type="submit" className="w-full bg-primary hover:bg-blue-600 text-white font-bold py-4 rounded-xl transition-all shadow-[0_0_20px_rgba(0,102,255,0.4)] flex justify-center items-center gap-2 group">
                    Create Profile <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                </button>
            </form>
        )}

        {/* Loading State */}
        {step === 'verifying' && (
            <div className="text-center py-10 animate-pulse">
                <Loader2 size={48} className="animate-spin text-primary mx-auto mb-4" />
                <p className="text-gray-400">Securing connection to database...</p>
            </div>
        )}

        {/* Step 2: OTP */}
        {step === 'otp' && (
            <div className="animate-slide-up text-center">
                <div className="mb-6">
                    <ShieldCheck size={40} className="text-accent mx-auto mb-2" />
                    <h2 className="text-xl font-bold text-white">Verify Identity</h2>
                    <p className="text-xs text-gray-500">Enter the code sent to {formData.phone}</p>
                </div>
                
                <div className="flex justify-center gap-3 mb-8">
                    {otp.map((digit, idx) => (
                        <input
                            key={idx} id={`otp-${idx}`}
                            type="text" maxLength={1}
                            value={digit}
                            onChange={(e) => handleOtpChange(idx, e.target.value)}
                            className="w-14 h-14 bg-dark border border-gray-700 rounded-xl text-center text-2xl font-bold text-white focus:border-accent focus:ring-1 focus:ring-accent outline-none"
                        />
                    ))}
                </div>

                <button 
                    onClick={handleVerifyOtp}
                    className="w-full bg-accent hover:bg-green-400 text-dark font-bold py-4 rounded-xl transition-all shadow-[0_0_20px_rgba(0,255,136,0.3)]"
                >
                    Verify & Access
                </button>
                <button onClick={() => setStep('form')} className="mt-4 text-xs text-gray-500 hover:text-white">
                    Wrong number? Go back
                </button>
            </div>
        )}

        {/* Step 3: Success */}
        {step === 'success' && (
             <div className="text-center py-10 animate-slide-up">
                <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-[0_0_30px_rgba(0,255,136,0.6)]">
                    <CheckCircle size={40} className="text-white" />
                </div>
                <h2 className="text-2xl font-bold text-white">Access Granted</h2>
                <p className="text-gray-400">Welcome to the team, {formData.name.split(' ')[0]}.</p>
            </div>
        )}

        {step === 'form' && (
            <div className="mt-6 text-center text-sm text-gray-500">
                Already have an account? <Link to="/login" className="text-primary font-bold hover:text-blue-400 neon-text">Log in</Link>
            </div>
        )}
      </div>
    </div>
  );
};

export default Signup;
