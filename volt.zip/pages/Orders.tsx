
import React from 'react';
import { useApp } from '../context/AppContext';
import { Link } from 'react-router-dom';
import { Clock, ArrowRight, Trash2 } from 'lucide-react';

const Orders: React.FC = () => {
  const { orders, deleteOrder } = useApp();

  const handleDelete = (e: React.MouseEvent, id: string) => {
      e.preventDefault();
      e.stopPropagation();
      if(window.confirm("Remove this order record from history?")) {
          deleteOrder(id);
      }
  };

  return (
    <div className="pb-20">
        <h1 className="text-2xl font-bold text-white mb-6 font-display">Fuel Logs</h1>
        {orders.length === 0 ? (
            <div className="text-center py-12 bg-card rounded-2xl border border-dashed border-gray-700">
                <p className="text-gray-500">No logs found.</p>
                <Link to="/app/machines" className="text-primary font-bold mt-2 inline-block hover:underline">Start an order</Link>
            </div>
        ) : (
            <div className="space-y-4">
                {orders.map(order => (
                    <Link key={order.id} to={`/app/orders/${order.id}`} className="block bg-card p-5 rounded-xl border border-darkBorder hover:border-primary/50 transition-all group shadow-sm relative">
                        <div className="flex justify-between items-start mb-4">
                            <div>
                                <h3 className="font-bold text-lg text-gray-200 group-hover:text-primary transition-colors">{order.shake.name || 'Custom Mix'}</h3>
                                <p className="text-sm text-gray-500">{order.machineName}</p>
                            </div>
                            <div className="text-right">
                                <span className="block font-bold text-white">₹{order.totalAmount}</span>
                                <span className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded ${
                                    order.status === 'Completed' ? 'text-accent border border-accent/20' : 
                                    order.status === 'Pending' ? 'text-yellow-400 border border-yellow-400/20' : 'text-gray-400'
                                }`}>
                                    {order.status}
                                </span>
                            </div>
                        </div>
                        <div className="flex justify-between items-center text-xs text-gray-500 border-t border-darkBorder pt-3">
                            <span className="flex items-center gap-1"><Clock size={12} /> {new Date(order.date).toLocaleDateString()}</span>
                            <div className="flex gap-4 z-20">
                                <button 
                                    onClick={(e) => handleDelete(e, order.id)} 
                                    className="text-gray-600 hover:text-red-500 transition-colors p-1"
                                    title="Delete Log"
                                >
                                    <Trash2 size={16} />
                                </button>
                                <span className="flex items-center gap-1 text-primary font-medium opacity-0 group-hover:opacity-100 transition-opacity">Details <ArrowRight size={12} /></span>
                            </div>
                        </div>
                    </Link>
                ))}
            </div>
        )}
    </div>
  );
};

export default Orders;
