import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Wallet as WalletIcon, Plus, CreditCard, ChevronRight } from 'lucide-react';

const WalletPage: React.FC = () => {
  const { user, updateWallet } = useApp();
  const [amount, setAmount] = useState<string>('');
  
  const handleAddMoney = (e: React.FormEvent) => {
      e.preventDefault();
      const val = parseInt(amount);
      if (val > 0) {
          updateWallet(val);
          setAmount('');
          alert(`Successfully added ₹${val} to wallet!`);
      }
  };

  return (
    <div className="space-y-6">
      {/* Balance Card */}
      <div className="bg-gradient-to-br from-card to-darkBorder p-6 rounded-2xl shadow-xl border border-darkBorder relative overflow-hidden">
          <div className="absolute top-0 right-0 w-40 h-40 bg-primary/10 rounded-full blur-3xl"></div>
          <div className="flex items-center gap-2 text-gray-400 mb-2">
              <WalletIcon size={20} />
              <span className="text-sm font-medium uppercase tracking-wide">Current Balance</span>
          </div>
          <div className="text-5xl font-bold text-white font-display tracking-tight">₹{user?.walletBalance}</div>
      </div>

      {/* Add Money */}
      <div className="bg-card p-6 rounded-2xl border border-darkBorder">
          <h2 className="font-bold text-lg text-white mb-4 font-display">Add Credits</h2>
          
          <div className="flex gap-3 mb-4">
              {[200, 500, 1000].map(val => (
                  <button 
                    key={val}
                    onClick={() => setAmount(val.toString())}
                    className="flex-1 py-2 border border-gray-700 rounded-lg text-sm font-medium text-gray-300 hover:border-primary hover:bg-primary/10 hover:text-primary transition-all"
                  >
                      +₹{val}
                  </button>
              ))}
          </div>

          <form onSubmit={handleAddMoney}>
              <div className="flex gap-2">
                  <div className="relative flex-1">
                      <span className="absolute left-3 top-2.5 text-gray-500">₹</span>
                      <input 
                        type="number" 
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        placeholder="Enter amount"
                        className="w-full pl-8 pr-4 py-2 bg-dark border border-gray-700 rounded-lg text-white focus:ring-2 focus:ring-primary outline-none transition-all placeholder-gray-600"
                        min="1"
                      />
                  </div>
                  <button 
                    type="submit"
                    disabled={!amount}
                    className="bg-primary text-dark px-6 rounded-lg font-bold hover:bg-cyan-400 disabled:opacity-50 transition-colors"
                  >
                      Add
                  </button>
              </div>
          </form>
      </div>

      {/* Transaction History (Mock) */}
      <div>
          <h2 className="font-bold text-lg text-white mb-4 font-display">Ledger</h2>
          <div className="space-y-3">
              <div className="bg-card p-4 rounded-xl border border-darkBorder flex justify-between items-center hover:bg-gray-800/50 transition-colors cursor-pointer group">
                  <div className="flex gap-3 items-center">
                      <div className="w-10 h-10 bg-green-500/10 text-green-500 rounded-full flex items-center justify-center border border-green-500/20">
                          <Plus size={18} />
                      </div>
                      <div>
                          <p className="font-bold text-sm text-gray-200">Wallet Top-up</p>
                          <p className="text-xs text-gray-500">Today, 10:00 AM</p>
                      </div>
                  </div>
                  <div className="flex items-center gap-2">
                      <span className="font-bold text-green-400">+₹500</span>
                      <ChevronRight size={14} className="text-gray-600 group-hover:text-primary" />
                  </div>
              </div>
              <div className="bg-card p-4 rounded-xl border border-darkBorder flex justify-between items-center hover:bg-gray-800/50 transition-colors cursor-pointer group">
                  <div className="flex gap-3 items-center">
                      <div className="w-10 h-10 bg-orange-500/10 text-orange-500 rounded-full flex items-center justify-center border border-orange-500/20">
                          <CreditCard size={18} />
                      </div>
                      <div>
                          <p className="font-bold text-sm text-gray-200">Order #8832</p>
                          <p className="text-xs text-gray-500">Yesterday, 6:30 PM</p>
                      </div>
                  </div>
                  <div className="flex items-center gap-2">
                      <span className="font-bold text-gray-300">-₹140</span>
                      <ChevronRight size={14} className="text-gray-600 group-hover:text-primary" />
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
};

export default WalletPage;