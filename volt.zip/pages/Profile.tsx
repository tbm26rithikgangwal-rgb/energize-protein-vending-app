
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Mail, Phone, Dumbbell, Zap, Edit2, Save, X, Flame, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Profile: React.FC = () => {
  const { user, logout, updateProfile, deleteUser } = useApp();
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState<any>({});
  const navigate = useNavigate();

  if (!user) return null;

  const startEdit = () => {
      setEditForm({ name: user.name, phone: user.phone, fitnessGoal: user.fitnessGoal });
      setIsEditing(true);
  };

  const handleSave = async () => {
      await updateProfile(editForm);
      setIsEditing(false);
  };

  const handleDeleteAccount = () => {
      if(window.confirm("Are you sure? This action is irreversible and will wipe your energy score.")) {
          deleteUser();
          navigate('/');
      }
  };

  return (
    <div className="space-y-6 pb-20">
        <div className="flex justify-between items-center">
             <h1 className="text-2xl font-bold text-white font-display">Identity</h1>
             {!isEditing && (
                 <button onClick={startEdit} className="text-primary hover:text-white transition-colors">
                     <Edit2 size={20} />
                 </button>
             )}
        </div>
        
        {/* Avatar & Streak */}
        <div className="bg-card rounded-2xl p-8 border border-darkBorder flex flex-col items-center text-center relative overflow-hidden">
            <div className="absolute top-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent"></div>
            
            <div className="w-24 h-24 bg-dark text-white rounded-full flex items-center justify-center text-3xl font-bold mb-4 border-2 border-primary shadow-[0_0_20px_rgba(0,102,255,0.3)]">
                {user.name[0]}
            </div>
            
            {isEditing ? (
                <input 
                    className="bg-dark border border-gray-700 text-white text-center font-bold text-xl rounded p-1 w-full max-w-[200px]"
                    value={editForm.name}
                    onChange={e => setEditForm({...editForm, name: e.target.value})}
                />
            ) : (
                <h2 className="text-xl font-bold text-white">{user.name}</h2>
            )}
            
            <div className="flex items-center gap-2 mt-2 text-energy font-bold bg-energy/10 px-3 py-1 rounded-full border border-energy/20">
                <Flame size={14} fill="currentColor" /> {user.streak} Day Streak
            </div>
        </div>

        {/* Details */}
        <div className="bg-card rounded-2xl border border-darkBorder overflow-hidden">
            <div className="p-4 border-b border-darkBorder flex items-center gap-4">
                <Mail size={20} className="text-gray-500" />
                <div className="flex-1">
                    <p className="text-xs text-gray-500 uppercase">Email</p>
                    <p className="text-sm font-medium text-gray-200">{user.email}</p>
                </div>
            </div>
            <div className="p-4 border-b border-darkBorder flex items-center gap-4">
                <Phone size={20} className="text-gray-500" />
                <div className="flex-1">
                    <p className="text-xs text-gray-500 uppercase">Phone</p>
                    {isEditing ? (
                        <input 
                            className="bg-dark border border-gray-700 text-white text-sm rounded p-1 w-full"
                            value={editForm.phone}
                            onChange={e => setEditForm({...editForm, phone: e.target.value})}
                        />
                    ) : (
                        <p className="text-sm font-medium text-gray-200">{user.phone}</p>
                    )}
                </div>
            </div>
            <div className="p-4 border-b border-darkBorder flex items-center gap-4">
                <Dumbbell size={20} className="text-gray-500" />
                <div className="flex-1">
                    <p className="text-xs text-gray-500 uppercase">Goal</p>
                     {isEditing ? (
                        <select 
                            className="bg-dark border border-gray-700 text-white text-sm rounded p-1 w-full"
                            value={editForm.fitnessGoal}
                            onChange={e => setEditForm({...editForm, fitnessGoal: e.target.value})}
                        >
                            <option value="Bulking">Bulking</option>
                            <option value="Cutting">Cutting</option>
                            <option value="Fitness">Fitness</option>
                        </select>
                    ) : (
                        <p className="text-sm font-medium text-gray-200">{user.fitnessGoal}</p>
                    )}
                </div>
            </div>
            <div className="p-4 flex items-center gap-4">
                <Zap size={20} className="text-gray-500" />
                <div className="flex-1">
                    <p className="text-xs text-gray-500 uppercase">Preferred Fuel</p>
                    <p className="text-sm font-medium text-gray-200">{user.preferences.proteinType}</p>
                </div>
            </div>
        </div>

        {isEditing ? (
            <div className="flex gap-4">
                <button onClick={handleSave} className="flex-1 bg-primary text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2">
                    <Save size={18} /> Save
                </button>
                <button onClick={() => setIsEditing(false)} className="flex-1 bg-gray-800 text-gray-400 py-3 rounded-xl font-bold flex items-center justify-center gap-2">
                    <X size={18} /> Cancel
                </button>
            </div>
        ) : (
            <div className="space-y-4">
                <button onClick={logout} className="w-full bg-gray-800 text-white py-4 rounded-xl font-bold hover:bg-gray-700 transition-colors uppercase tracking-wide">
                    Log Out
                </button>
                <button onClick={handleDeleteAccount} className="w-full text-red-500 py-2 rounded-xl text-xs font-bold hover:text-red-400 transition-colors uppercase tracking-wide flex items-center justify-center gap-2">
                    <Trash2 size={14} /> Delete Account
                </button>
            </div>
        )}
    </div>
  );
};

export default Profile;
