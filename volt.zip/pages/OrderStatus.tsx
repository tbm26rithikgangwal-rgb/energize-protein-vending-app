
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { CheckCircle, RefreshCw, AlertCircle, Zap, Box, BatteryCharging } from 'lucide-react';
import { OrderStatus as StatusEnum } from '../types';

const OrderStatus: React.FC = () => {
  const { id } = useParams();
  const { getOrder } = useApp();
  const order = getOrder(id || '');
  const [showCelebration, setShowCelebration] = useState(false);

  useEffect(() => {
    if (order?.status === StatusEnum.COMPLETED) {
        setShowCelebration(true);
    }
  }, [order?.status]);

  if (!order) return <div className="p-8 text-center text-white">Order not found.</div>;

  const steps = [
      { status: StatusEnum.PENDING, label: 'Initiating', icon: <RefreshCw className="animate-spin" /> },
      { status: StatusEnum.PAID, label: 'Payment Secured', icon: <CheckCircle /> },
      { status: StatusEnum.DISPENSING, label: 'Mixing Fuel', icon: <Zap className="animate-pulse" /> },
      { status: StatusEnum.COMPLETED, label: 'Ready to Lift', icon: <Box /> }
  ];

  const currentStepIndex = steps.findIndex(s => s.status === order.status);
  const isFailed = order.status === StatusEnum.FAILED || order.status === StatusEnum.REFUNDED;

  return (
    <div className="max-w-md mx-auto pt-8 relative">
      {/* FULL SCREEN CELEBRATION OVERLAY */}
      {showCelebration && (
          <div className="fixed inset-0 z-50 bg-dark/95 flex flex-col items-center justify-center animate-fade-in">
             <div className="absolute inset-0 overflow-hidden pointer-events-none">
                 {[...Array(20)].map((_, i) => (
                     <div key={i} className="absolute w-2 h-2 rounded-full bg-primary animate-float"
                          style={{ left: `${Math.random()*100}%`, top: `${Math.random()*100}%`, animationDuration: `${1+Math.random()*2}s` }}>
                     </div>
                 ))}
             </div>
             
             <div className="relative mb-8">
                 <BatteryCharging size={100} className="text-accent animate-pulse" />
                 <div className="absolute inset-0 bg-accent/20 blur-3xl rounded-full"></div>
             </div>
             
             <h1 className="text-4xl font-bold text-white font-display mb-2 animate-slide-up text-center">
                 ENERGY <br/> <span className="text-accent">RECHARGED</span>
             </h1>
             <p className="text-gray-400 mb-8 animate-slide-up delay-100">Protein Loaded. +20 Energy Score.</p>
             
             <button 
                onClick={() => setShowCelebration(false)}
                className="bg-white text-dark px-10 py-4 rounded-full font-bold text-lg hover:scale-105 transition-transform animate-slide-up delay-200"
             >
                 CONTINUE
             </button>
          </div>
      )}

      {/* Main Content */}
      <div className="text-center mb-10">
          <div className="inline-block px-3 py-1 rounded-full bg-gray-800 border border-gray-700 text-xs text-gray-400 mb-4 font-mono">
              ID: {order.id.slice(-6).toUpperCase()}
          </div>
          <h1 className="text-3xl font-bold text-white mb-2 font-display tracking-wide neon-text">
            {order.status === StatusEnum.COMPLETED ? 'FUEL READY' : 'PROCESSING'}
          </h1>
          <p className="text-gray-500">{order.machineName}</p>
      </div>

      {isFailed ? (
          <div className="bg-red-500/10 p-6 rounded-2xl border border-red-500/20 text-center animate-pulse">
              <div className="w-16 h-16 bg-red-500/20 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <AlertCircle size={32} />
              </div>
              <h2 className="font-bold text-lg text-red-400 mb-2">System Error</h2>
              <p className="text-red-300 text-sm mb-4">Refund of ₹{order.totalAmount} processed.</p>
              <Link to="/app/machines" className="bg-red-500 text-white px-6 py-2 rounded-lg font-medium inline-block hover:bg-red-600 transition-colors">Try Another Unit</Link>
          </div>
      ) : (
          <div className="bg-card p-8 rounded-2xl shadow-xl border border-darkBorder relative overflow-hidden">
               <div className="absolute top-0 left-0 w-1 h-full bg-gray-800 ml-9 z-0"></div>
               <div className="absolute top-0 left-0 w-1 bg-primary ml-9 z-0 transition-all duration-1000" style={{ height: `${(currentStepIndex + 1) * 25}%` }}></div>

              <div className="space-y-8 relative z-10">
                  {steps.map((step, idx) => {
                      const isCompleted = currentStepIndex >= idx;
                      const isCurrent = currentStepIndex === idx;

                      return (
                        <div key={step.status} className={`flex gap-6 transition-all ${isCompleted ? 'opacity-100' : 'opacity-40'}`}>
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all ${
                                isCompleted 
                                ? 'bg-primary border-primary text-white shadow-[0_0_15px_rgba(0,102,255,0.5)]' 
                                : 'bg-dark border-gray-700 text-gray-500'
                            }`}>
                                {React.cloneElement(step.icon as any, { size: 18 })}
                            </div>
                            <div className="pt-2">
                                <h3 className={`text-sm font-bold uppercase tracking-wider ${isCurrent ? 'text-primary neon-text' : 'text-gray-300'}`}>
                                    {step.label}
                                </h3>
                                {isCurrent && order.status !== StatusEnum.COMPLETED && (
                                    <p className="text-xs text-primary/70 animate-pulse mt-1">Working...</p>
                                )}
                            </div>
                        </div>
                      );
                  })}
              </div>
          </div>
      )}

      {order.status === StatusEnum.COMPLETED && (
          <div className="mt-8 animate-slide-up">
              <Link to="/app/home" className="block w-full bg-white text-dark hover:bg-gray-200 text-center py-4 rounded-xl font-bold transition-all shadow-lg shadow-white/10 uppercase tracking-widest text-sm">
                  Return to Base
              </Link>
          </div>
      )}
    </div>
  );
};

export default OrderStatus;
