import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Zap, ArrowLeft } from 'lucide-react';

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useApp();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && password) {
        login(email);
        navigate('/app/home');
    }
  };

  return (
    <div className="min-h-screen bg-dark flex items-center justify-center p-4 relative">
      <Link to="/" className="absolute top-6 left-6 text-gray-500 hover:text-white flex items-center gap-2 transition-colors">
          <ArrowLeft size={20} /> Back to Home
      </Link>

      <div className="bg-card w-full max-w-md p-8 rounded-2xl shadow-2xl border border-darkBorder">
        <div className="text-center mb-8">
            <div className="w-12 h-12 bg-primary/10 text-primary rounded-xl flex items-center justify-center mx-auto mb-4 border border-primary/20">
                <Zap size={24} fill="currentColor" />
            </div>
            <h1 className="text-2xl font-bold text-white font-display">Welcome Back</h1>
            <p className="text-gray-500 mt-1">Access your Volt wallet</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label className="block text-xs font-bold text-gray-400 mb-1 uppercase tracking-wide">Email Address</label>
                <input 
                    type="email" 
                    required 
                    className="w-full px-4 py-3 bg-dark border border-darkBorder rounded-xl text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all placeholder-gray-600"
                    placeholder="you@example.com"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                />
            </div>
            <div>
                <label className="block text-xs font-bold text-gray-400 mb-1 uppercase tracking-wide">Password</label>
                <input 
                    type="password" 
                    required 
                    className="w-full px-4 py-3 bg-dark border border-darkBorder rounded-xl text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all placeholder-gray-600"
                    placeholder="••••••••"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                />
            </div>
            
            <button type="submit" className="w-full bg-primary hover:bg-cyan-400 text-dark font-bold py-3.5 rounded-xl transition-all shadow-lg shadow-cyan-500/20">
                Log In
            </button>
        </form>

        <div className="mt-6 text-center text-sm text-gray-500">
            Don't have an account? <Link to="/signup" className="text-primary font-bold hover:text-cyan-300">Sign up</Link>
        </div>
      </div>
    </div>
  );
};

export default Login;