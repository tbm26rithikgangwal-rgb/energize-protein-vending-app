import React from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { ArrowRight, CheckCircle, Smartphone, MapPin, Zap, Activity } from 'lucide-react';
import { MACHINES } from '../constants';

const Landing: React.FC = () => {
  const { user } = useApp();

  return (
    <div className="min-h-screen bg-dark text-white">
      {/* Hero */}
      <div className="relative overflow-hidden pt-28 pb-20 px-6">
        {/* Abstract Background Effects */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-primary/20 rounded-full blur-[120px] -z-10"></div>
        <div className="absolute bottom-0 right-0 w-[600px] h-[400px] bg-indigo-500/10 rounded-full blur-[100px] -z-10"></div>

        <div className="max-w-4xl mx-auto text-center relative z-10">
            <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-4 py-1.5 mb-6 backdrop-blur-sm">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                </span>
                <span className="text-xs font-medium text-gray-300 tracking-wide uppercase">AI Vending Online</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-8 leading-tight font-display">
                Volt <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-blue-400 to-indigo-500 animate-glow">
                    Instantly & Intelligently
                </span>
            </h1>
            <p className="text-lg md:text-xl text-gray-400 mb-10 max-w-2xl mx-auto">
                The first AI-powered protein station in Gurgaon Cyberpark. 
                <span className="text-white"> Analyze your workout</span>, get a custom blend, and collect it in seconds.
            </p>
            <div className="flex flex-col sm:flex-row gap-5 justify-center">
                <Link to={user ? "/app/home" : "/signup"} className="bg-primary hover:bg-cyan-400 text-dark px-10 py-4 rounded-full font-bold text-lg transition-all hover:scale-105 shadow-[0_0_20px_rgba(6,182,212,0.5)] flex items-center justify-center gap-2">
                    Get Started <ArrowRight size={20} />
                </Link>
                <Link to="/login" className="bg-white/5 hover:bg-white/10 border border-white/10 text-white px-10 py-4 rounded-full font-semibold text-lg backdrop-blur-sm transition-colors">
                    Member Login
                </Link>
            </div>
        </div>
      </div>

      {/* How it works */}
      <div className="py-20 px-6 bg-card/50 border-y border-darkBorder">
        <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center text-white mb-16 font-display">Workflow <span className="text-primary">Protocol</span></h2>
            <div className="grid md:grid-cols-3 gap-8">
                <div className="bg-card p-8 rounded-2xl border border-darkBorder hover:border-primary/50 transition-colors group relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    <div className="w-16 h-16 bg-card border border-darkBorder rounded-2xl flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 transition-transform">
                        <Smartphone size={32} className="text-primary" />
                    </div>
                    <h3 className="text-xl font-bold mb-3">1. Connect</h3>
                    <p className="text-gray-400 text-sm leading-relaxed">Secure signup via email & phone. Instant wallet top-up via UPI.</p>
                </div>
                <div className="bg-card p-8 rounded-2xl border border-darkBorder hover:border-primary/50 transition-colors group relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    <div className="w-16 h-16 bg-card border border-darkBorder rounded-2xl flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 transition-transform">
                        <Activity size={32} className="text-accent" />
                    </div>
                    <h3 className="text-xl font-bold mb-3">2. Analyze</h3>
                    <p className="text-gray-400 text-sm leading-relaxed">Tell AI your workout stats. It builds the perfect macro-nutrient profile.</p>
                </div>
                <div className="bg-card p-8 rounded-2xl border border-darkBorder hover:border-primary/50 transition-colors group relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    <div className="w-16 h-16 bg-card border border-darkBorder rounded-2xl flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 transition-transform">
                        <Zap size={32} className="text-green-500" />
                    </div>
                    <h3 className="text-xl font-bold mb-3">3. Energize</h3>
                    <p className="text-gray-400 text-sm leading-relaxed">Scan QR at the machine. Dispenses fresh in under 45 seconds.</p>
                </div>
            </div>
        </div>
      </div>

      {/* Locations */}
      <div className="py-20 px-6">
        <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center text-white mb-12 font-display">Deployment <span className="text-primary">Nodes</span></h2>
            <div className="grid md:grid-cols-2 gap-6">
                {MACHINES.slice(0, 2).map(m => (
                    <div key={m.id} className="bg-card border border-darkBorder rounded-2xl p-6 flex items-start justify-between hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5 transition-all cursor-pointer group">
                        <div>
                            <h3 className="font-bold text-lg text-white group-hover:text-primary transition-colors">{m.name}</h3>
                            <p className="text-gray-500 mt-2 flex items-center gap-2 text-sm"><MapPin size={16}/> {m.location}</p>
                            <span className={`inline-flex items-center gap-1.5 mt-4 px-3 py-1 text-xs rounded-full font-medium ${m.status === 'Online' ? 'bg-green-500/10 text-green-400 border border-green-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'}`}>
                                <span className={`w-1.5 h-1.5 rounded-full ${m.status === 'Online' ? 'bg-green-500' : 'bg-red-500'}`}></span>
                                {m.status}
                            </span>
                        </div>
                        <div className="text-gray-600 group-hover:text-primary transition-colors">
                            <ArrowRight size={24} />
                        </div>
                    </div>
                ))}
            </div>
            <div className="text-center mt-12">
                <Link to="/signup" className="text-primary font-bold hover:text-cyan-300 transition-colors uppercase tracking-wider text-sm">Join the Network &rarr;</Link>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Landing;