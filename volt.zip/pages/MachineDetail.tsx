import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { MACHINES, PRESETS } from '../constants';
import { MapPin, ArrowRight } from 'lucide-react';

const MachineDetail: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const machine = MACHINES.find(m => m.id === id);

  if (!machine) return <div className="p-4 text-white">Machine not found</div>;

  const isOnline = machine.status === 'Online';

  return (
    <div className="space-y-6 pb-24">
       {/* Header */}
       <div className="bg-card p-6 rounded-2xl border border-darkBorder shadow-sm relative overflow-hidden">
            <div className="flex items-start justify-between relative z-10">
                <div>
                    <h1 className="text-2xl font-bold text-white font-display">{machine.name}</h1>
                    <p className="text-gray-400 flex items-center gap-1 mt-1 text-sm"><MapPin size={16} /> {machine.location}</p>
                </div>
                <div className={`px-3 py-1 rounded-full text-sm font-bold border ${isOnline ? 'bg-green-500/10 text-green-400 border-green-500/20' : 'bg-red-500/10 text-red-400 border-red-500/20'}`}>
                    {machine.status}
                </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mt-6 relative z-10">
                <div className="bg-dark p-3 rounded-xl border border-darkBorder text-center">
                    <span className="block text-xs text-gray-500 uppercase font-bold tracking-wider">Queue</span>
                    <span className="block text-xl font-bold text-white">{machine.queueLength} <span className="text-sm font-normal text-gray-600">waiting</span></span>
                </div>
                <div className="bg-dark p-3 rounded-xl border border-darkBorder text-center">
                    <span className="block text-xs text-gray-500 uppercase font-bold tracking-wider">Inventory</span>
                    <span className="block text-xl font-bold text-green-400">Good</span>
                </div>
            </div>
       </div>

       {/* Presets */}
       <div>
           <h2 className="text-lg font-bold text-white mb-4 font-display">Quick Select</h2>
           <div className="space-y-3">
               {PRESETS.map(preset => (
                   <div key={preset.id} className="bg-card p-4 rounded-xl border border-darkBorder flex justify-between items-center group hover:border-primary/50 transition-all cursor-pointer"
                        onClick={() => navigate(`/app/shake-builder?machineId=${machine.id}&preset=${preset.id}`)}>
                       <div>
                           <h3 className="font-bold text-gray-200 group-hover:text-primary transition-colors">{preset.name}</h3>
                           <p className="text-xs text-gray-500 mt-1">{preset.macros.protein}g Protein • {preset.macros.calories} kcal</p>
                           <p className="font-semibold text-white mt-1">₹{preset.price}</p>
                       </div>
                       <div className="w-8 h-8 rounded-full bg-dark border border-gray-700 flex items-center justify-center text-gray-400 group-hover:bg-primary group-hover:text-dark group-hover:border-primary transition-all">
                           <ArrowRight size={16} />
                       </div>
                   </div>
               ))}
           </div>
       </div>

       {/* Sticky Bottom Action */}
       <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-darkBorder p-4 shadow-2xl z-30 md:relative md:border-0 md:shadow-none md:bg-transparent md:p-0">
           <div className="max-w-4xl mx-auto">
               <button 
                onClick={() => navigate(`/app/shake-builder?machineId=${machine.id}`)}
                disabled={!isOnline}
                className={`w-full py-4 rounded-xl font-bold text-lg shadow-lg flex items-center justify-center gap-2 transition-all ${
                    isOnline 
                    ? 'bg-primary hover:bg-cyan-400 text-dark shadow-cyan-500/20' 
                    : 'bg-gray-800 text-gray-500 cursor-not-allowed border border-gray-700'
                }`}
               >
                   {isOnline ? 'Start Custom Build' : 'Unit Offline'}
                   {isOnline && <ArrowRight size={20} />}
               </button>
           </div>
       </div>
    </div>
  );
};

export default MachineDetail;