
import { GoogleGenAI } from "@google/genai";
import { User, Machine, ShakeRecipe } from "../types";

// Replace this with your Gemini API Key if process.env is not available
// Get it from: https://aistudio.google.com/app/apikey
const HARDCODED_API_KEY = ""; 

const getApiKey = () => {
  // Check for environment variable or hardcoded key
  const key = (typeof process !== 'undefined' && process.env?.API_KEY) || HARDCODED_API_KEY;
  if (!key) {
    console.warn("Gemini API_KEY not found. Using Mock AI logic.");
    return null;
  }
  return key;
};

// 1. NEURO-FUEL ARCHITECT
export const analyzeWorkoutForShake = async (workoutDescription: string): Promise<Partial<ShakeRecipe> & { reasoning: string }> => {
  const key = getApiKey();
  
  // MOCK FALLBACK (If no key provided)
  if (!key) {
    return new Promise(resolve => setTimeout(() => resolve({
      name: "Mock Bio-Hack Blend",
      description: "Optimized for heavy lifting (Mock Data).",
      base: "isolate",
      flavor: "chocolate",
      size: "Large",
      addOns: ["creatine", "bcaa"],
      sweetness: 50,
      ice: "Extra",
      reasoning: "API Key missing. Simulating analysis: Detected high-intensity lifting. Isolate selected for rapid absorption."
    }), 1500));
  }

  const ai = new GoogleGenAI({ apiKey: key });
  
  const prompt = `
    User Workout Data: "${workoutDescription}"
    
    You are the "Neuro-Fuel Architect", an elite sports nutritionist AI. 
    Design a custom protein shake to maximize recovery for this specific workout.
    
    Constraints:
    - Bases: Whey, Isolate, Vegan.
    - Flavors: Chocolate, Vanilla, Strawberry, Coffee, Banana.
    - AddOns: creatine, bcaa, pb (Peanut Butter), scoop (Extra Scoop).
    
    Tone: High-energy, scientific, motivating.
    
    Output JSON:
    {
        "name": "Cool sci-fi name",
        "description": "Short description.",
        "reasoning": "Scientific reason.",
        "base": "string",
        "flavor": "string",
        "size": "Small" | "Medium" | "Large",
        "addOns": ["string"],
        "sweetness": number,
        "ice": "No Ice" | "Normal" | "Extra"
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: { responseMimeType: "application/json" }
    });

    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("AI Error:", error);
    return {
       name: "Emergency Recovery",
       base: "whey",
       flavor: "vanilla",
       size: "Medium",
       addOns: [],
       sweetness: 50,
       ice: "Normal",
       description: "Standard recovery shake.",
       reasoning: "AI connection failed. Defaulting to standard macro profile."
    };
  }
};

// 2. HYPE-BOT: Context Aware
export const getMotivationQuote = async (user: User): Promise<string> => {
    const key = getApiKey();
    const timeOfDay = new Date().getHours() < 12 ? "morning" : "evening";
    const energyLevel = user.energyScore < 40 ? "Low Energy" : "High Energy";
    
    if (!key) return `Streak: ${user.streak} Days. Energy: ${user.energyScore}%. Keep pushing!`;
    
    const ai = new GoogleGenAI({ apiKey: key });
    const prompt = `
      User Context:
      - Streak: ${user.streak} days
      - Energy Score: ${user.energyScore}/100 (${energyLevel})
      - Time: ${timeOfDay}
      
      Give me a short, explosive, 1-sentence motivation quote.
      If energy is low, tell them to refuel. If streak is high, praise them.
    `;
    
    try {
        const res = await ai.models.generateContent({ model: "gemini-2.5-flash", contents: prompt });
        return res.text?.trim() || "Fuel the Beast within!";
    } catch {
        return "Dominate your recovery!";
    }
}

// 3. MACHINE SELECTOR AGENT
export const suggestMachine = async (query: string, machines: Machine[]): Promise<string> => {
  const key = getApiKey();
  if (!key) return machines[0]?.id || "";

  const ai = new GoogleGenAI({ apiKey: key });
  const machineData = machines.map(m => `${m.id}: ${m.name} (${m.status}, Queue: ${m.queueLength}, Stocks: ${JSON.stringify(m.stockLevel)})`).join('\n');
  
  const prompt = `
    Query: "${query}"
    Machines: ${machineData}
    Pick the best machine ID. Prioritize Online status. Return ONLY the ID.
  `;

  try {
    const response = await ai.models.generateContent({ model: "gemini-2.5-flash", contents: prompt });
    return response.text?.trim() || machines[0].id;
  } catch {
    return machines[0].id;
  }
};

// 4. CHAT ASSISTANT
export const chatWithAI = async (message: string): Promise<string> => {
  const key = getApiKey();
  if (!key) return "I am running in offline mode. Configure API Key for real intelligence.";

  const ai = new GoogleGenAI({ apiKey: key });
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: message,
      config: {
        systemInstruction: "You are 'Volt Bot', a high-energy gym assistant. Keep answers short, punchy, and use gym slang."
      }
    });
    return response.text || "Fuel up and go!";
  } catch {
    return "Connection interrupted. Keep lifting.";
  }
};
