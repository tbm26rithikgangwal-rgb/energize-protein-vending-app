
import { createClient } from '@supabase/supabase-js';

// ------------------------------------------------------------------
// 🚀 FINAL STEP: PASTE YOUR SUPABASE KEYS HERE
// ------------------------------------------------------------------
// 1. Go to Supabase Dashboard -> Settings -> API
// 2. Copy "Project URL" and "anon public" key

const SUPABASE_URL = 'https://lhobdnxqpeumziioorlj.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxob2JkbnhxcGV1bXppaW9vcmxqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ2OTg2NTIsImV4cCI6MjA4MDI3NDY1Mn0.3S3AB-undAhUtSY8viOd7RGr_QqMH_rzegTxu13IQX4';

if (!SUPABASE_URL || !SUPABASE_ANON_KEY || SUPABASE_URL.includes('your-project-id')) {
  console.warn('⚠️ Supabase Keys might be missing or invalid! The app will not connect to the database.');
}

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
