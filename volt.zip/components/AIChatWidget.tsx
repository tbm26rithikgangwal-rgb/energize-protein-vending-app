import React, { useState } from 'react';
import { chatWithAI } from '../services/geminiService';
import { MessageCircle, X, Send, Bot } from 'lucide-react';

const AIChatWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: 'user'|'ai', text: string}[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSend = async () => {
    if (!input.trim()) return;
    
    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
        const response = await chatWithAI(userMsg);
        setMessages(prev => [...prev, { role: 'ai', text: response }]);
    } catch (e) {
        setMessages(prev => [...prev, { role: 'ai', text: "Sorry, I couldn't reach the server." }]);
    } finally {
        setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end font-sans">
      {isOpen && (
        <div className="bg-card mb-4 w-80 h-[28rem] rounded-2xl shadow-2xl border border-darkBorder flex flex-col overflow-hidden animate-fade-in-up">
            <div className="bg-gradient-to-r from-primary to-blue-600 p-4 text-white flex justify-between items-center shadow-lg">
                <h3 className="font-bold flex items-center gap-2">
                    <Bot size={20} />
                    ProteinBot
                </h3>
                <button onClick={() => setIsOpen(false)} className="hover:bg-white/20 p-1 rounded transition-colors">
                    <X size={18} />
                </button>
            </div>
            
            <div className="flex-1 p-4 overflow-y-auto bg-dark flex flex-col gap-3">
                {messages.length === 0 && (
                    <div className="text-center mt-10 space-y-2">
                        <div className="w-12 h-12 bg-gray-800 rounded-full flex items-center justify-center mx-auto text-primary">
                            <Bot size={24} />
                        </div>
                        <p className="text-gray-400 text-sm">Ask me about shakes, machines, or macros!</p>
                    </div>
                )}
                {messages.map((m, i) => (
                    <div key={i} className={`max-w-[85%] p-3 rounded-xl text-sm leading-relaxed ${
                        m.role === 'user' 
                        ? 'bg-primary text-dark self-end rounded-br-none font-medium' 
                        : 'bg-gray-800 border border-gray-700 text-gray-200 self-start rounded-bl-none shadow-sm'
                    }`}>
                        {m.text}
                    </div>
                ))}
                {loading && (
                    <div className="bg-gray-800 border border-gray-700 p-3 rounded-xl rounded-bl-none w-14 flex justify-center shadow-sm">
                        <div className="flex gap-1">
                            <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce"></span>
                            <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce delay-100"></span>
                            <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce delay-200"></span>
                        </div>
                    </div>
                )}
            </div>

            <div className="p-3 bg-card border-t border-darkBorder flex gap-2">
                <input 
                    type="text" 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Type a message..."
                    className="flex-1 bg-dark border border-gray-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all placeholder-gray-600"
                />
                <button 
                    onClick={handleSend}
                    disabled={!input.trim() || loading}
                    className="bg-primary text-dark p-2 rounded-lg hover:bg-cyan-400 disabled:opacity-50 transition-colors"
                >
                    <Send size={18} />
                </button>
            </div>
        </div>
      )}

      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="bg-primary text-dark p-4 rounded-full shadow-[0_0_20px_rgba(6,182,212,0.4)] hover:bg-cyan-400 hover:scale-110 transition-all active:scale-95"
      >
        {isOpen ? <X size={24} /> : <MessageCircle size={24} />}
      </button>
    </div>
  );
};

export default AIChatWidget;