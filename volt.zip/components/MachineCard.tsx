import React from 'react';
import { Machine } from '../types';
import { MapPin, Activity, Battery, User as UserIcon } from 'lucide-react';

interface MachineCardProps {
  machine: Machine;
  onSelect: (id: string) => void;
  compact?: boolean;
}

const MachineCard: React.FC<MachineCardProps> = ({ machine, onSelect, compact }) => {
  const isOnline = machine.status === 'Online';

  return (
    <div className={`bg-card rounded-2xl border border-darkBorder overflow-hidden hover:border-primary/50 transition-all group ${compact ? 'p-4' : 'p-6'}`}>
      <div className="flex justify-between items-start mb-2">
        <div>
            <h3 className="font-bold text-white text-lg font-display group-hover:text-primary transition-colors">{machine.name}</h3>
            <p className="text-gray-400 text-sm flex items-center gap-1 mt-1">
                <MapPin size={14} /> {machine.location}
            </p>
        </div>
        <div className={`px-2 py-1 rounded-full text-xs font-medium flex items-center gap-1 border ${
            isOnline 
            ? 'bg-green-500/10 text-green-400 border-green-500/20' 
            : 'bg-red-500/10 text-red-400 border-red-500/20'
        }`}>
            <Activity size={12} />
            {machine.status}
        </div>
      </div>

      <div className="flex gap-4 mt-4 text-sm text-gray-500">
        <div className="flex items-center gap-1">
            <UserIcon size={14} />
            <span>Queue: <span className="text-white">{machine.queueLength}</span></span>
        </div>
        <div className="flex items-center gap-1">
            <Battery size={14} />
            <span>Whey: <span className="text-white">{machine.stockLevel.whey}%</span></span>
        </div>
        <div className="flex items-center gap-1 ml-auto font-medium text-primary">
            {machine.distance}
        </div>
      </div>

      <button
        onClick={() => onSelect(machine.id)}
        disabled={!isOnline}
        className={`w-full mt-5 py-3 rounded-xl font-bold transition-all ${
            isOnline 
            ? 'bg-primary hover:bg-cyan-400 text-dark shadow-lg shadow-cyan-500/10' 
            : 'bg-gray-800 text-gray-500 cursor-not-allowed border border-gray-700'
        }`}
      >
        {isOnline ? 'Select Machine' : 'System Offline'}
      </button>
    </div>
  );
};

export default MachineCard;