
export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  walletBalance: number;
  fitnessGoal: 'Bulking' | 'Cutting' | 'Fitness';
  streak: number; 
  lastStreakDate?: string; // ISO Date string
  energyScore: number; // 0-100 Gamification score
  preferences: {
    proteinType: 'Whey' | 'Isolate' | 'Vegan';
  };
}

export interface MacroData {
  protein: number;
  carbs: number;
  fats: number;
  calories: number;
}

export interface Machine {
  id: string;
  name: string;
  location: string;
  status: 'Online' | 'Offline' | 'Maintenance';
  stockLevel: {
    whey: number; // Percentage
    vegan: number; // Percentage
  };
  queueLength: number;
  distance: string;
  coordinates: { lat: number; lng: number };
}

export interface ShakeRecipe {
  id?: string;
  base: string;
  flavor: string;
  size: 'Small' | 'Medium' | 'Large';
  addOns: string[];
  sweetness: number; // 0-100
  ice: 'No Ice' | 'Normal' | 'Extra';
  macros?: MacroData;
  price: number;
  name?: string;
  description?: string;
  isAiGenerated?: boolean;
}

export enum OrderStatus {
  PENDING = 'Pending',
  PAID = 'Paid',
  DISPENSING = 'Dispensing',
  COMPLETED = 'Completed',
  FAILED = 'Failed',
  REFUNDED = 'Refunded',
}

export interface Order {
  id: string;
  date: string;
  machineId: string;
  machineName: string;
  shake: ShakeRecipe;
  totalAmount: number;
  status: OrderStatus;
}