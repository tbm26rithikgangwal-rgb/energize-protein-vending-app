import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, Order, ShakeRecipe, OrderStatus } from '../types';
import { MACHINES } from '../constants';
import { supabase } from '../services/supabaseClient';

interface AppContextType {
  user: User | null;
  login: (email: string, password?: string) => Promise<void>;
  signup: (userData: Partial<User> & { password?: string }) => Promise<void>;
  logout: () => void;
  deleteUser: () => Promise<void>;
  updateWallet: (amount: number) => Promise<void>;
  updateProfile: (data: Partial<User>) => Promise<void>;
  orders: Order[];
  createOrder: (machineId: string, shake: ShakeRecipe, amount: number) => Promise<string>;
  deleteOrder: (orderId: string) => Promise<void>;
  getOrder: (id: string) => Order | undefined;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Initial Energy State
const DEFAULT_ENERGY = 40;

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  // 1. Check Active Session on Mount
  useEffect(() => {
    const fetchSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        await fetchUserData(session.user.id);
      }
      setLoading(false);
    };

    fetchSession();

    // Listen for auth changes
    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        fetchUserData(session.user.id);
      } else {
        setUser(null);
        setOrders([]);
      }
    });

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, []);

  // Helper: Fetch User Profile & Orders from Supabase
  const fetchUserData = async (userId: string) => {
    try {
      // Fetch Profile
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (profileError) throw profileError;

      if (profile) {
        // Map snake_case (DB) to camelCase (App)
        const mappedUser: User = {
          id: profile.id,
          name: profile.name || 'Athlete',
          email: profile.email || '',
          phone: profile.phone || '',
          walletBalance: profile.wallet_balance || 0,
          fitnessGoal: profile.fitness_goal || 'Fitness',
          streak: profile.streak || 0,
          energyScore: profile.energy_score || DEFAULT_ENERGY,
          lastStreakDate: profile.last_streak_date,
          preferences: profile.preferences || { proteinType: 'Whey' }
        };
        setUser(mappedUser);
      }

      // Fetch Orders
      const { data: ordersData, error: ordersError } = await supabase
        .from('orders')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (ordersError) throw ordersError;

      if (ordersData) {
        const mappedOrders: Order[] = ordersData.map((o: any) => ({
          id: o.id,
          date: o.created_at,
          machineId: o.machine_id,
          machineName: o.machine_name,
          shake: o.shake_config, // JSONB comes as object
          totalAmount: o.total_amount,
          status: o.status as OrderStatus
        }));
        setOrders(mappedOrders);
      }

    } catch (err) {
      console.error("Error fetching data:", err);
    }
  };

  const login = async (email: string, password?: string) => {
    if (!password) throw new Error("Password required");
    
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) throw error;
    // Auth state listener will handle the rest
  };

  const signup = async (userData: Partial<User> & { password?: string }) => {
    if (!userData.email || !userData.password) throw new Error("Missing credentials");

    // 1. Create Auth User
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: userData.email,
      password: userData.password,
    });

    if (authError) throw authError;
    if (!authData.user) throw new Error("Signup failed");

    // 2. Create Public Profile
    // We map app camelCase to DB snake_case
    const newProfile = {
      id: authData.user.id,
      email: userData.email,
      name: userData.name || 'New Athlete',
      phone: userData.phone || '',
      wallet_balance: 100, // Sign up bonus
      fitness_goal: 'Fitness',
      streak: 1,
      energy_score: DEFAULT_ENERGY,
      last_streak_date: new Date().toISOString(),
      preferences: { proteinType: 'Whey' }
    };

    const { error: profileError } = await supabase
      .from('profiles')
      .insert([newProfile]);

    if (profileError) throw profileError;

    // Fetch fresh data
    await fetchUserData(authData.user.id);
  };

  const logout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setOrders([]);
  };

  const deleteUser = async () => {
    if (!user) return;
    
    // In Supabase, usually users can't delete their own Auth record directly via client API for security.
    // We delete the profile, and a backend Trigger should handle auth cleanup, OR we just sign out.
    // For this demo, we'll try to delete the profile row.
    const { error } = await supabase.from('profiles').delete().eq('id', user.id);
    if (error) {
      console.error("Error deleting profile:", error);
      alert("Could not delete account. Contact support.");
      return;
    }
    await logout();
  };

  const updateWallet = async (amount: number) => {
    if (!user) return;
    
    const newBalance = user.walletBalance + amount;
    
    const { error } = await supabase
      .from('profiles')
      .update({ wallet_balance: newBalance })
      .eq('id', user.id);

    if (error) {
      console.error("Wallet update failed:", error);
      return;
    }
    
    // Optimistic update
    setUser({ ...user, walletBalance: newBalance });
  };

  const updateProfile = async (data: Partial<User>) => {
    if (!user) return;

    // Map partial update to snake_case
    const dbUpdate: any = {};
    if (data.name) dbUpdate.name = data.name;
    if (data.phone) dbUpdate.phone = data.phone;
    if (data.fitnessGoal) dbUpdate.fitness_goal = data.fitnessGoal;
    
    const { error } = await supabase
      .from('profiles')
      .update(dbUpdate)
      .eq('id', user.id);

    if (error) {
      console.error("Profile update failed:", error);
      return;
    }

    // Optimistic update
    setUser({ ...user, ...data });
  };

  // --- CORE GAME LOOP LOGIC ---
  const calculateStreakAndEnergy = (currentUser: User): { streak: number, energy: number, date: string } => {
      const now = new Date();
      const last = currentUser.lastStreakDate ? new Date(currentUser.lastStreakDate) : new Date(0);
      
      const isSameDay = now.toDateString() === last.toDateString();
      const isYesterday = new Date(now.getTime() - 86400000).toDateString() === last.toDateString();
      
      let newStreak = currentUser.streak;
      if (!isSameDay) {
          if (isYesterday) newStreak += 1;
          else newStreak = 1; // Reset if missed a day
      }

      // Energy Boost cap at 100
      let newEnergy = Math.min(currentUser.energyScore + 20, 100);

      return {
          streak: newStreak,
          energy: newEnergy,
          date: now.toISOString()
      };
  };

  const createOrder = async (machineId: string, shake: ShakeRecipe, amount: number): Promise<string> => {
      if (!user) throw new Error('Not logged in');
      if (user.walletBalance < amount) throw new Error('Insufficient funds');

      const machineName = MACHINES.find(m => m.id === machineId)?.name || 'Unknown Machine';

      // 1. Insert Order
      const { data: orderData, error: orderError } = await supabase
        .from('orders')
        .insert([{
          user_id: user.id,
          machine_id: machineId,
          machine_name: machineName,
          shake_config: shake,
          total_amount: amount,
          status: OrderStatus.PENDING
        }])
        .select()
        .single();

      if (orderError) throw orderError;

      // 2. Deduct Wallet (Atomic update would be better via RPC, but client-side for now)
      const newBalance = user.walletBalance - amount;
      await supabase.from('profiles').update({ wallet_balance: newBalance }).eq('id', user.id);
      setUser(prev => prev ? { ...prev, walletBalance: newBalance } : null);

      // 3. Simulate Lifecycle (Updates DB status)
      setTimeout(() => updateOrderStatusDB(orderData.id, OrderStatus.PAID), 1500);
      setTimeout(() => updateOrderStatusDB(orderData.id, OrderStatus.DISPENSING), 3500);
      
      setTimeout(async () => {
          // 4. On Completion: Apply Energy & Streak Logic
          await updateOrderStatusDB(orderData.id, OrderStatus.COMPLETED);
          
          // Calculate Gamification stats
          const stats = calculateStreakAndEnergy(user);
          
          // Update Profile with new stats
          await supabase.from('profiles').update({
            streak: stats.streak,
            energy_score: stats.energy,
            last_streak_date: stats.date
          }).eq('id', user.id);

          // Update local state
          setUser(prev => prev ? {
            ...prev,
            streak: stats.streak,
            energyScore: stats.energy,
            lastStreakDate: stats.date
          } : null);

      }, 8000);

      // Add to local list immediately for UI responsiveness
      const newOrderLocal: Order = {
        id: orderData.id,
        date: orderData.created_at,
        machineId,
        machineName,
        shake,
        totalAmount: amount,
        status: OrderStatus.PENDING
      };
      setOrders(prev => [newOrderLocal, ...prev]);

      return orderData.id;
  };

  const updateOrderStatusDB = async (orderId: string, status: OrderStatus) => {
    await supabase.from('orders').update({ status }).eq('id', orderId);
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
  };

  const deleteOrder = async (orderId: string) => {
    const { error } = await supabase.from('orders').delete().eq('id', orderId);
    if (!error) {
      setOrders(prev => prev.filter(o => o.id !== orderId));
    }
  };

  const getOrder = (id: string) => orders.find(o => o.id === id);

  return (
    <AppContext.Provider value={{ user, login, signup, logout, deleteUser, updateWallet, updateProfile, orders, createOrder, deleteOrder, getOrder }}>
      {!loading && children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};