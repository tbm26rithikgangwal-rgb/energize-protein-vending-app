import React from 'react';
import { HashRouter, Routes, Route, Navigate, useLocation, Link, Outlet } from 'react-router-dom';
import { AppProvider, useApp } from './context/AppContext';
import { Home as HomeIcon, Coffee, ShoppingBag, Wallet, User, LogOut, Menu, X, Zap } from 'lucide-react';
import AIChatWidget from './components/AIChatWidget';

// Pages
import Landing from './pages/Landing';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Home from './pages/Home';
import Machines from './pages/Machines';
import MachineDetail from './pages/MachineDetail';
import ShakeBuilder from './pages/ShakeBuilder';
import OrderSummary from './pages/OrderSummary';
import Orders from './pages/Orders';
import OrderStatus from './pages/OrderStatus';
import WalletPage from './pages/Wallet';
import Profile from './pages/Profile';
import Help from './pages/Help';

// Layout Component
const Layout: React.FC = () => {
  const { user, logout } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const location = useLocation();

  if (!user) return <Navigate to="/login" />;

  const isActive = (path: string) => location.pathname.startsWith(path) 
    ? 'text-primary bg-primary/10 border-primary' 
    : 'text-gray-400 hover:text-white hover:bg-gray-800 border-transparent';

  return (
    <div className="min-h-screen flex flex-col bg-dark text-gray-200 font-sans selection:bg-primary selection:text-white">
      <header className="sticky top-0 z-40 bg-card/80 backdrop-blur-md border-b border-darkBorder shadow-lg">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/app/home" className="flex items-center gap-2 font-bold text-xl tracking-tight text-white group">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center text-white shadow-lg shadow-primary/20 group-hover:scale-105 transition-transform">
              <Zap size={18} strokeWidth={3} />
            </div>
            <span className="group-hover:text-primary transition-colors">Volt</span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-2">
            <Link to="/app/home" className={`px-4 py-2 rounded-lg text-sm font-medium border transition-all ${isActive('/app/home')}`}>Home</Link>
            <Link to="/app/machines" className={`px-4 py-2 rounded-lg text-sm font-medium border transition-all ${isActive('/app/machines')}`}>Machines</Link>
            <Link to="/app/orders" className={`px-4 py-2 rounded-lg text-sm font-medium border transition-all ${isActive('/app/orders')}`}>Orders</Link>
          </nav>

          <div className="flex items-center gap-3">
             <Link to="/app/wallet" className="hidden md:flex items-center gap-2 bg-gray-800 hover:bg-gray-700 border border-gray-700 px-3 py-1.5 rounded-full text-sm font-bold text-gray-200 transition-colors">
                <Wallet size={16} className="text-primary" />
                ₹{user.walletBalance}
             </Link>
             
             <div className="relative group">
                <Link to="/app/profile" className="w-9 h-9 bg-gray-800 text-primary border border-gray-700 rounded-full flex items-center justify-center font-bold hover:bg-gray-700 transition-colors">
                    {user.name[0]}
                </Link>
                {/* Desktop Dropdown */}
                <div className="hidden group-hover:block absolute right-0 top-full mt-2 w-48 bg-card rounded-xl shadow-xl border border-darkBorder py-1 animate-fade-in z-50">
                    <Link to="/app/profile" className="block px-4 py-2 text-sm text-gray-300 hover:bg-gray-800 hover:text-white">Profile</Link>
                    <Link to="/app/help" className="block px-4 py-2 text-sm text-gray-300 hover:bg-gray-800 hover:text-white">Help & Support</Link>
                    <button onClick={logout} className="w-full text-left px-4 py-2 text-sm text-red-400 hover:bg-red-900/20">Logout</button>
                </div>
             </div>
             
             {/* Mobile Menu Toggle */}
             <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden p-2 text-gray-300 hover:text-white">
                {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
             </button>
          </div>
        </div>

        {/* Mobile Nav */}
        {mobileMenuOpen && (
            <div className="md:hidden bg-card border-t border-darkBorder px-4 py-4 space-y-2 absolute w-full shadow-2xl">
                <Link onClick={() => setMobileMenuOpen(false)} to="/app/home" className={`block px-4 py-3 rounded-lg font-medium border ${isActive('/app/home')}`}>Home</Link>
                <Link onClick={() => setMobileMenuOpen(false)} to="/app/machines" className={`block px-4 py-3 rounded-lg font-medium border ${isActive('/app/machines')}`}>Machines</Link>
                <Link onClick={() => setMobileMenuOpen(false)} to="/app/orders" className={`block px-4 py-3 rounded-lg font-medium border ${isActive('/app/orders')}`}>Orders</Link>
                <Link onClick={() => setMobileMenuOpen(false)} to="/app/wallet" className={`block px-4 py-3 rounded-lg font-medium border ${isActive('/app/wallet')}`}>
                    Wallet (₹{user.walletBalance})
                </Link>
                <button onClick={logout} className="block w-full text-left px-4 py-3 rounded-lg font-medium text-red-400 hover:bg-red-900/10">Logout</button>
            </div>
        )}
      </header>

      <main className="flex-1 max-w-4xl mx-auto w-full p-4 md:p-6">
        <Outlet />
      </main>

      <footer className="border-t border-darkBorder mt-auto bg-card">
        <div className="max-w-4xl mx-auto px-4 py-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-500">
            <p>&copy; {new Date().getFullYear()} Volt AI. Powered by Gemini.</p>
            <div className="flex gap-6">
                <a href="#" className="hover:text-primary transition-colors">Privacy</a>
                <a href="#" className="hover:text-primary transition-colors">Terms</a>
                <a href="#" className="hover:text-primary transition-colors">Locations</a>
            </div>
        </div>
      </footer>

      <AIChatWidget />
    </div>
  );
};

// Main App Router
const AppContent = () => {
    return (
      <HashRouter>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />

          {/* Protected Routes */}
          <Route path="/app" element={<Layout />}>
            <Route path="home" element={<Home />} />
            <Route path="machines" element={<Machines />} />
            <Route path="machines/:id" element={<MachineDetail />} />
            <Route path="shake-builder" element={<ShakeBuilder />} />
            <Route path="order-summary" element={<OrderSummary />} />
            <Route path="orders" element={<Orders />} />
            <Route path="orders/:id" element={<OrderStatus />} />
            <Route path="wallet" element={<WalletPage />} />
            <Route path="profile" element={<Profile />} />
            <Route path="help" element={<Help />} />
          </Route>

          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </HashRouter>
    );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}